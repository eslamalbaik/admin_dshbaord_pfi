import{t as e}from"./vendor_vue-VH0AEJSL.js";const o=e({__name:"lms",setup(t){return()=>{}}});export{o as default};

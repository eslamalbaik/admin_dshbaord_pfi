<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponseTrait;
use App\Models\Tender;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TenderController extends Controller
{
    use ApiResponseTrait;

    // GET /api/tenders
    public function index(Request $request)
    {
        $query = Tender::query();

        if ($request->filled('search')) {
            $query->where('title', 'like', '%' . $request->search . '%');
        }
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('category')) {
            $query->where('category', $request->category);
        }

        return $this->paginated($query->latest()->paginate(15));
    }

    // POST /api/tenders
    public function store(Request $request)
    {
        $validated = $request->validate([
            'title'              => 'required|string|max:255',
            'description'        => 'nullable|string',
            'union_notes'        => 'nullable|string',
            'category'           => 'nullable|string|max:100',
            'deadline'           => 'nullable|date',
            'status'             => 'nullable|in:open,closed,cancelled',
            'submission_types'   => 'nullable|array',
            'submission_types.*' => 'in:email,phone,file',
            'submission_email'   => 'nullable|email|max:255',
            'submission_phone'   => 'nullable|string|max:20',
            'submission_file'    => 'nullable|file|mimes:pdf,doc,docx|max:5120',
        ]);

        if ($request->hasFile('submission_file')) {
            $validated['submission_file'] = $request->file('submission_file')
                ->store('tenders/files', 'public');
        }

        if (isset($validated['submission_types'])) {
            $validated['submission_types'] = array_values(array_filter($validated['submission_types']));
        }

        $validated['created_by'] = Auth::id();
        $tender = Tender::create($validated);

        return $this->success($tender->toArray(), 'تم إضافة المناقصة بنجاح.', 201);
    }

    // GET /api/tenders/{id}
    public function show(Tender $tender)
    {
        return $this->success($tender->toArray());
    }

    // PATCH /api/tenders/{id}
    public function update(Request $request, Tender $tender)
    {
        $validated = $request->validate([
            'title'              => 'sometimes|string|max:255',
            'description'        => 'nullable|string',
            'union_notes'        => 'nullable|string',
            'category'           => 'nullable|string|max:100',
            'deadline'           => 'nullable|date',
            'status'             => 'nullable|in:open,closed,cancelled',
            'submission_types'   => 'nullable|array',
            'submission_types.*' => 'in:email,phone,file',
            'submission_email'   => 'nullable|email|max:255',
            'submission_phone'   => 'nullable|string|max:20',
            'submission_file'    => 'nullable|file|mimes:pdf,doc,docx|max:5120',
        ]);

        if ($request->hasFile('submission_file')) {
            $validated['submission_file'] = $request->file('submission_file')
                ->store('tenders/files', 'public');
        }

        if (isset($validated['submission_types'])) {
            $validated['submission_types'] = array_values(array_filter($validated['submission_types']));
        }

        $tender->update($validated);

        return $this->success($tender->fresh()->toArray(), 'تم تحديث المناقصة بنجاح.');
    }

    // DELETE /api/tenders/{id}
    public function destroy(Tender $tender)
    {
        $tender->delete();

        return $this->success(message: 'تم حذف المناقصة بنجاح.');
    }
}

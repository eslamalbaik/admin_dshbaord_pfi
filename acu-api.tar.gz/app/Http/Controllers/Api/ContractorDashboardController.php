<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponseTrait;
use Illuminate\Http\Request;

class ContractorDashboardController extends Controller
{
    use ApiResponseTrait;
    // ─────────────────────────────────────────────────────────────────────────
    //  GET /api/v1/contractor/dashboard
    // ─────────────────────────────────────────────────────────────────────────
    public function index(Request $request)
    {
        $contractor = $request->user();

        $activeMembership = $contractor->memberships()
            ->where('status', 'active')
            ->latest('starts_at')
            ->first();

        return $this->success([
            'contractor' => [
                'id'                => $contractor->id,
                'name'              => $contractor->name,
                'membership_number' => $contractor->membership_number,
                'commercial_register' => $contractor->commercial_register,
                'authorized_person' => $contractor->authorized_person,
                'trade'             => $contractor->trade,
                'classification'    => $contractor->classification,
                'email'             => $contractor->email,
                'phone'             => $contractor->phone,
                'city'              => $contractor->city,
                'address'           => $contractor->address,
                'status'            => $contractor->status,
                'is_frozen'         => $contractor->is_frozen,
            ],
            'membership' => $activeMembership ? [
                'id'          => $activeMembership->id,
                'type'        => $activeMembership->type,
                'status'      => $activeMembership->status,
                'starts_at'   => $activeMembership->starts_at?->toDateString(),
                'expires_at'  => $activeMembership->expires_at?->toDateString(),
                'amount'      => $activeMembership->amount,
                'expiring_soon' => $activeMembership->expiring_soon,
            ] : null,
            'stats' => [
                'total_payments'   => $contractor->payments()->where('status', 'paid')->sum('amount'),
                'pending_payments' => $contractor->payments()->where('status', 'pending')->count(),
                'total_documents'  => $contractor->documents()->count(),
            ],
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  GET /api/v1/contractor/memberships
    // ─────────────────────────────────────────────────────────────────────────
    public function memberships(Request $request)
    {
        $memberships = $request->user()
            ->memberships()
            ->latest()
            ->get()
            ->map(fn($m) => [
                'id'          => $m->id,
                'type'        => $m->type,
                'status'      => $m->status,
                'starts_at'   => $m->starts_at?->toDateString(),
                'expires_at'  => $m->expires_at?->toDateString(),
                'amount'      => $m->amount,
                'notes'       => $m->notes,
                'expiring_soon' => $m->expiring_soon,
            ]);

        return $this->success($memberships->toArray());
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  GET /api/v1/contractor/payments
    // ─────────────────────────────────────────────────────────────────────────
    public function payments(Request $request)
    {
        $payments = $request->user()
            ->payments()
            ->with('membership:id,type,expires_at')
            ->latest()
            ->get()
            ->map(fn($p) => [
                'id'               => $p->id,
                'amount'           => $p->amount,
                'type'             => $p->type,
                'status'           => $p->status,
                'method'           => $p->method,
                'reference_number' => $p->reference_number,
                'notes'            => $p->notes,
                'paid_at'          => $p->paid_at?->toDateString(),
                'created_at'       => $p->created_at->toDateString(),
                'membership'       => $p->membership ? [
                    'type'       => $p->membership->type,
                    'expires_at' => $p->membership->expires_at?->toDateString(),
                ] : null,
            ]);

        return $this->success($payments->toArray());
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  GET /api/v1/contractor/documents
    // ─────────────────────────────────────────────────────────────────────────
    public function documents(Request $request)
    {
        $documents = $request->user()
            ->documents()
            ->latest()
            ->get()
            ->map(fn($d) => [
                'id'             => $d->id,
                'title'          => $d->title,
                'type'           => $d->type,
                'url'            => $d->url,
                'mime_type'      => $d->mime_type,
                'formatted_size' => $d->formatted_size,
                'created_at'     => $d->created_at->toDateString(),
            ]);

        return response()->json(['data' => $documents]);
    }
}

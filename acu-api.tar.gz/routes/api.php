<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\Api\DashboardController;
use App\Http\Controllers\Api\ContractorController;
use App\Http\Controllers\Api\MembershipController;
use App\Http\Controllers\Api\PaymentController;
use App\Http\Controllers\Api\PenaltyController;
use App\Http\Controllers\Api\TenderController;
use App\Http\Controllers\Api\DocumentController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\NotificationController;
use App\Http\Controllers\Api\ContractorAuthController;
use App\Http\Controllers\Api\ContractorRegisterController;
use App\Http\Controllers\Api\ContractorDashboardController;
use App\Http\Controllers\Api\EquipmentTypeController;
use App\Http\Controllers\Api\EquipmentController;
use App\Http\Controllers\Api\ReportsController;
use App\Http\Controllers\Api\NewsController;

// ============================================================
//  API v1
// ============================================================
Route::prefix('v1')->group(function () {

    // --------------------------------------------------------
    //  Contractor Mobile App — Auth (Public)
    // --------------------------------------------------------
    Route::prefix('contractor/auth')->group(function () {
        // throttle: 5 محاولات كل دقيقة لمنع brute force
        Route::middleware('throttle:5,1')->post('login', [ContractorAuthController::class, 'login']);

        // تسجيل العضو (خطوتان): التحقق من الهوية ثم تعيين كلمة المرور
        Route::middleware('throttle:10,1')->group(function () {
            Route::post('verify-identity', [ContractorRegisterController::class, 'verifyIdentity']);
            Route::post('set-password',    [ContractorRegisterController::class, 'setPassword']);
            Route::post('verify-otp',      [ContractorRegisterController::class, 'verifyOtp']);
            Route::post('resend-otp',      [ContractorRegisterController::class, 'resendOtp']);
            Route::post('forgot-password/send-otp', [ContractorRegisterController::class, 'forgotPasswordSendOtp']);
            Route::post('forgot-password/reset',    [ContractorRegisterController::class, 'forgotPasswordReset']);
        });
    });

    // --------------------------------------------------------
    //  Contractor Mobile App — Auth (Protected)
    // --------------------------------------------------------
    Route::middleware('auth:sanctum')->prefix('contractor/auth')->group(function () {
        Route::post('logout',          [ContractorAuthController::class, 'logout']);
        Route::get('me',               [ContractorAuthController::class, 'me']);
        Route::patch('profile',        [ContractorAuthController::class, 'updateProfile']);
        Route::post('profile/update',  [ContractorAuthController::class, 'updateFullProfile']);
        Route::get('profile/pdf',      [ContractorAuthController::class, 'exportPdf']);
        Route::get('profile/download-file/{field}', [ContractorAuthController::class, 'downloadFile']);
        Route::post('change-password', [ContractorAuthController::class, 'changePassword']);
    });

    // --------------------------------------------------------
    //  Contractor Dashboard (Protected)
    // --------------------------------------------------------
    Route::middleware('auth:sanctum')->prefix('contractor')->group(function () {
        Route::get('dashboard',    [ContractorDashboardController::class, 'index']);
        Route::get('memberships',  [ContractorDashboardController::class, 'memberships']);
        Route::get('payments',     [ContractorDashboardController::class, 'payments']);
        Route::get('documents',    [ContractorDashboardController::class, 'documents']);
    });

    // --------------------------------------------------------
    //  News — Public (no auth)
    // --------------------------------------------------------
    Route::prefix('news')->group(function () {
        Route::get('latest',  [NewsController::class, 'latest']);
        Route::get('/',       [NewsController::class, 'index']);
        Route::get('{slug}',  [NewsController::class, 'show']);
    });

    // --------------------------------------------------------
    //  Admin Auth — Public
    // --------------------------------------------------------
    Route::prefix('auth')->group(function () {
        Route::post('login',    [AuthController::class, 'login']);
        Route::post('register', [AuthController::class, 'register']);

        // Google OAuth
        Route::get('google/redirect',  [AuthController::class, 'redirectToGoogle']);
        Route::post('google/exchange', [AuthController::class, 'exchangeGoogleCode']);
    });

    // --------------------------------------------------------
    //  Protected — Sanctum
    // --------------------------------------------------------
    Route::middleware('auth:sanctum')->group(function () {

        // بيانات المستخدم الحالي (authStore.fetchUser)
        Route::get('user', function (\Illuminate\Http\Request $request) {
            $user = $request->user();
            return response()->json([
                'id'       => $user->id,
                'fullName' => $user->name,
                'role'     => $user->role,
                'email'    => $user->email,
                'avatar'   => $user->avatar ?? null,
            ]);
        });

        // Admin Auth — me / logout
        Route::prefix('auth')->group(function () {
            Route::post('logout', [AuthController::class, 'logout']);
            Route::get('me', function (\Illuminate\Http\Request $request) {
                $user = $request->user();
                return response()->json([
                    'id'       => $user->id,
                    'fullName' => $user->name,
                    'role'     => $user->role,
                    'email'    => $user->email,
                    'avatar'   => $user->avatar ?? null,
                ]);
            });
        });

        // --------------------------------------------------------
        //  Dashboard
        // --------------------------------------------------------
        Route::get('dashboard/stats', [DashboardController::class, 'index']);

        // --------------------------------------------------------
        //  News — Admin CRUD
        // --------------------------------------------------------
        Route::prefix('admin/news')->group(function () {
            Route::get('/',          [NewsController::class, 'adminIndex']);
            Route::post('/',         [NewsController::class, 'store']);
            Route::put('{news}',     [NewsController::class, 'update']);
            Route::delete('{news}',  [NewsController::class, 'destroy']);
        });

        // --------------------------------------------------------
        //  Contractors
        // --------------------------------------------------------
        Route::get('contractors/next-membership-number', [ContractorController::class, 'nextMembershipNumber']);
        Route::apiResource('contractors', ContractorController::class)
             ->only(['index', 'store', 'show', 'update', 'destroy']);
        Route::post('contractors/{contractor}/qr', [ContractorController::class, 'generateQR']);

        // --------------------------------------------------------
        //  Memberships
        // --------------------------------------------------------
        Route::get('memberships/pending',               [MembershipController::class, 'pending']);
        Route::get('memberships',                       [MembershipController::class, 'index']);
        Route::post('memberships',                      [MembershipController::class, 'store']);
        Route::post('memberships/{membership}/approve', [MembershipController::class, 'approve']);
        Route::post('memberships/{membership}/reject',  [MembershipController::class, 'reject']);

        // --------------------------------------------------------
        //  Payments
        // --------------------------------------------------------
        Route::get('payments/transactions',  [PaymentController::class, 'index']);
        Route::post('payments/transactions', [PaymentController::class, 'store']);

        // --------------------------------------------------------
        //  Penalties
        // --------------------------------------------------------
        Route::get('penalties',                 [PenaltyController::class, 'index']);
        Route::post('penalties',                [PenaltyController::class, 'store']);
        Route::patch('penalties/{penalty}/pay', [PenaltyController::class, 'markPaid']);

        // --------------------------------------------------------
        //  Tenders
        // --------------------------------------------------------
        Route::apiResource('tenders', TenderController::class);

        // --------------------------------------------------------
        //  Documents
        // --------------------------------------------------------
        Route::get('documents',               [DocumentController::class, 'index']);
        Route::post('documents',              [DocumentController::class, 'store']);
        Route::delete('documents/{document}', [DocumentController::class, 'destroy']);

        // --------------------------------------------------------
        //  Users & Notifications
        // --------------------------------------------------------
        Route::get('users',               [UserController::class,         'index']);
        Route::get('notifications',                    [NotificationController::class, 'index']);
        Route::post('notifications/read',              [NotificationController::class, 'markAllRead']);
        Route::patch('notifications/{id}/mark-as-read', [NotificationController::class, 'markAsRead']);

        // --------------------------------------------------------
        //  Equipment Marketplace — سوق الآليات
        // --------------------------------------------------------
        Route::get('equipment-types',                    [EquipmentTypeController::class, 'index']);
        Route::post('equipment-types',                   [EquipmentTypeController::class, 'store']);
        Route::patch('equipment-types/{equipmentType}',  [EquipmentTypeController::class, 'update']);
        Route::delete('equipment-types/{equipmentType}', [EquipmentTypeController::class, 'destroy']);

        Route::get('equipment/stats',                    [EquipmentController::class, 'stats']);
        Route::get('equipment',                          [EquipmentController::class, 'index']);
        Route::post('equipment',                         [EquipmentController::class, 'store']);
        Route::get('equipment/{equipment}',              [EquipmentController::class, 'show']);
        Route::patch('equipment/{equipment}',            [EquipmentController::class, 'update']);
        Route::delete('equipment/{equipment}',           [EquipmentController::class, 'destroy']);

        Route::post('equipment/{equipment}/images',                          [EquipmentController::class, 'uploadImages']);
        Route::delete('equipment/{equipment}/images/{equipmentImage}',       [EquipmentController::class, 'deleteImage']);
        Route::post('equipment/{equipment}/images/{equipmentImage}/primary', [EquipmentController::class, 'setPrimaryImage']);

        Route::get('equipment/{equipment}/blocked-dates',                  [EquipmentController::class, 'blockedDates']);
        Route::post('equipment/{equipment}/blocked-dates',                 [EquipmentController::class, 'addBlockedDate']);
        Route::delete('equipment/{equipment}/blocked-dates/{blockedDate}', [EquipmentController::class, 'removeBlockedDate']);

        // --------------------------------------------------------
        //  Reports / Analytics
        // --------------------------------------------------------
        Route::prefix('reports')->group(function () {
            Route::get('summary',        [ReportsController::class, 'summary']);
            Route::get('export/pdf',     [ReportsController::class, 'exportPdf']);
            Route::get('export/excel',   [ReportsController::class, 'exportExcel']);
        });
    });
});
